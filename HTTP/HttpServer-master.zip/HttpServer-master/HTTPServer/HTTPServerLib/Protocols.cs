﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HTTPServerLib
{
    public enum Protocols
    {
        Http = 0,

        Https = 1
    }
}
